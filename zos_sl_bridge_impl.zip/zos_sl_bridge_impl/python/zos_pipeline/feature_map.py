from __future__ import annotations

from collections import Counter, defaultdict
from typing import Dict, Iterable, List

from .monster_lattice import hash_file_bytes, resonance_score_from_hash
from .trace_features import aggregate_shard_vector
from .types import FactRecord, FeatureVector, Query, ShardSummary


def _tokenize(s: str) -> List[str]:
    return [tok.lower() for tok in s.replace(":", " ").replace(",", " ").split() if tok.strip()]


def _fact_features(facts: Iterable[FactRecord]) -> Dict[str, float]:
    facts = list(facts)
    n = max(1, len(facts))
    pred = Counter(f.predicate for f in facts)
    roles = Counter()
    quals = Counter()
    for f in facts:
        for k in f.arguments:
            roles[f"role::{k}"] += 1
        for k, v in f.qualifiers.items():
            quals[f"qual::{k}::{v}"] += 1

    vec: Dict[str, float] = {
        "fact_count": float(len(facts)),
        "predicate_cardinality": float(len(pred)),
        "role_cardinality": float(len(roles)),
        "qualifier_cardinality": float(len(quals)),
    }
    for k, c in pred.items():
        vec[f"pred::{k}"] = c / n
    for k, c in roles.items():
        vec[k] = c / n
    for k, c in quals.items():
        vec[k] = c / n
    return vec


def build_phi(summary: ShardSummary) -> FeatureVector:
    fact_vec = _fact_features(summary.facts)
    trace_vec = aggregate_shard_vector(summary.trace_windows)

    summary_bytes = ("|".join(sorted(f.fact_id for f in summary.facts)) + "|" + summary.shard_id).encode("utf-8")
    res = resonance_score_from_hash(hash_file_bytes(summary_bytes))

    values = {}
    values.update(fact_vec)
    values.update({f"trace::{k}": v for k, v in trace_vec.items()})
    values.update({
        "lat::o71": float(res.o71),
        "lat::o59": float(res.o59),
        "lat::o47": float(res.o47),
        "lat::dist_primary": float(res.dist_primary),
        "lat::dist_secondary": float(res.dist_secondary),
        "lat::resonance_strength": float(res.resonance_strength),
        "lat::resonance_flag": 1.0 if res.resonance else 0.0,
    })
    return FeatureVector(shard_id=summary.shard_id, values=values)


def query_phi(query: Query) -> FeatureVector:
    tokens = _tokenize(query.text)
    token_counts = Counter(tokens)
    n = max(1, len(tokens))
    values: Dict[str, float] = {
        "query_token_count": float(len(tokens)),
        "query_selector_count": float(len(query.selectors)),
        "query_predicate_hint_count": float(len(query.predicate_hints)),
    }
    for token, c in token_counts.items():
        values[f"qtok::{token}"] = c / n
    for p in query.predicate_hints:
        values[f"pred::{p}"] = 1.0
    for role, value in query.role_hints.items():
        values[f"role::{role}"] = 1.0
        values[f"qrolev::{role}::{str(value).lower()}"] = 1.0
    return FeatureVector(shard_id=None, values=values)
