from .types import (
    Query, TraceEvent, TraceWindow, ShardSummary, FactRecord, RetrievalResult,
    ResonanceScore, FeatureVector,
)
from .monster_lattice import (
    hash_file_bytes, orbifold_coords, resonance_score, resonance_flag,
)
from .trace_features import (
    build_trace_window, trace_window_vector, aggregate_shard_vector,
    infer_domain_clusters,
)
from .feature_map import build_phi
from .retrieval import manifold_aware_rank
