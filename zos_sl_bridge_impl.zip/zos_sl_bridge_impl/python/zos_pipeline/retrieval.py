from __future__ import annotations

from math import sqrt
from typing import Dict, Iterable, List, Optional, Sequence

from .feature_map import build_phi, query_phi
from .monster_lattice import resonance_score_from_hash, hash_file_bytes
from .trace_features import infer_domain_clusters
from .types import Query, RetrievalResult, ShardSummary


def _cosine(a: Dict[str, float], b: Dict[str, float]) -> float:
    keys = set(a) | set(b)
    dot = sum(a.get(k, 0.0) * b.get(k, 0.0) for k in keys)
    na = sqrt(sum(v * v for v in a.values()))
    nb = sqrt(sum(v * v for v in b.values()))
    if na == 0 or nb == 0:
        return 0.0
    return dot / (na * nb)


def manifold_aware_rank(
    query: Query,
    summaries: Sequence[ShardSummary],
    k_domains: int = 5,
    top_k: Optional[int] = None,
) -> List[RetrievalResult]:
    all_windows = [w for s in summaries for w in s.trace_windows]
    domain_map = infer_domain_clusters(all_windows, k=k_domains) if all_windows else {}

    shard_domain: Dict[str, int] = {}
    for s in summaries:
        labels = [domain_map[w.window_id] for w in s.trace_windows if w.window_id in domain_map]
        if labels:
            shard_domain[s.shard_id] = max(set(labels), key=labels.count)

    q_vec = query_phi(query)
    q_domain = None  # unknown upfront unless trained externally

    results: List[RetrievalResult] = []
    for s in summaries:
        s_vec = build_phi(s)
        domain_match = 1.0 if q_domain is None or shard_domain.get(s.shard_id) == q_domain else 0.5

        summary_bytes = ("|".join(sorted(f.fact_id for f in s.facts)) + "|" + s.shard_id).encode("utf-8")
        res = resonance_score_from_hash(hash_file_bytes(summary_bytes))
        spectral_score = _cosine(q_vec.values, s_vec.values)
        score = 0.65 * spectral_score + 0.20 * res.resonance_strength + 0.15 * domain_match

        reasons = []
        if res.resonance:
            reasons.append("lattice_resonance")
        if spectral_score > 0.25:
            reasons.append("spectral_alignment")
        if domain_match >= 1.0:
            reasons.append("domain_match")

        results.append(
            RetrievalResult(
                shard_id=s.shard_id,
                score=score,
                spectral_score=spectral_score,
                resonance_strength=res.resonance_strength,
                domain_match=domain_match,
                reasons=reasons,
            )
        )

    results.sort(key=lambda r: r.score, reverse=True)
    return results[:top_k] if top_k is not None else results
