from zos_pipeline.monster_lattice import resonance_score
from zos_pipeline.retrieval import manifold_aware_rank
from zos_pipeline.types import FactRecord, Query, ShardSummary, TraceEvent, TraceWindow


def test_resonance_pipeline_smoke():
    score = resonance_score(b"tenant mould high severity")
    assert 0 <= score.o71 < 71
    assert 0 <= score.o59 < 59
    assert 0 <= score.o47 < 47


def test_ranking_prefers_housing():
    shard_a = ShardSummary(
        shard_id="tenant_a",
        facts=[
            FactRecord("f1", "housing_issue", {"tenant": "p1", "issue": "mould"}, {"severity": "high"}),
            FactRecord("f2", "complaint", {"tenant": "p2", "issue": "dampness"}, {"severity": "high"}),
        ],
        trace_windows=[TraceWindow("w1", "tenant_a", [TraceEvent(1, "extract", "promote_fact", {"r1": 1}, ["cone_ok"], "loopA")])],
    )
    shard_b = ShardSummary(
        shard_id="runtime_b",
        facts=[FactRecord("f3", "service_event", {"service": "node", "status": "up"})],
        trace_windows=[TraceWindow("w2", "runtime_b", [TraceEvent(1, "runtime", "sync_peer", {"r1": 8}, ["loop_ok"], "loopB")])],
    )
    q = Query("q1", "tenant mould complaint", predicate_hints=["housing_issue"], role_hints={"tenant": "any"})
    out = manifold_aware_rank(q, [shard_a, shard_b], top_k=2)
    assert out[0].shard_id == "tenant_a"
