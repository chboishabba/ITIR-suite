# SL ↔ erdfa/Kant ↔ Zelph Prototype

This package implements a bounded prototype of:

1. Monster-hash surrogate → orbifold projection `(h % 71, h % 59, h % 47)`
2. Resonance test in the `o71-o59` plane using the generator offset from the uploaded SVG
3. `Φ` feature map combining:
   - SL fact features
   - zkperf trace-window features
   - lattice resonance features
4. Auto domain clustering from traces (unsupervised k-means over trace-window vectors)
5. Manifold-aware spectral retrieval:
   - selector/candidate set assumed upstream
   - rank candidate shards by cosine similarity over `Φ`
   - add resonance and domain-match priors

## Important limitation

The exact `monster-hash(file)` algorithm was not available in the pasted artifact.  
This prototype uses a SHA-256-derived 64-bit integer as a deterministic stand-in, behind a replaceable function.

## Test entry points

- Python:
  - `python -m zos_pipeline.cli --query "tenant mould complaint"`
- Rust:
  - `cargo run`

## Suggested next validation steps

- replace surrogate hash with real `monster-hash`
- feed real zkperf trace windows
- compare retrieval precision@k against SL-promoted facts
- compare `ΔMDL` with/without resonance features
