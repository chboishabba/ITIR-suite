# ZOS / SL bridge implementation bundle

This artifact contains:

- `python/zos_pipeline/`
- `python/tests/`
- `rust/zos_pipeline_rs/`
- `docs/INTEGRATION_NOTE.md`

Generated as a bounded reference implementation for:

- resonance pipeline
- Φ feature map
- domain classifier from traces
- manifold-aware spectral retrieval
